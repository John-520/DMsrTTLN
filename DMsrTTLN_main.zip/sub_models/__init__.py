#!/usr/bin/python
# -*- coding:utf-8 -*-
from sub_models.TICNN_PGDDTN import TICNN_PGDDTN as TICNN_PGDDTN
from sub_models.resnet18_1d import resnet18_features as resnet_features_1d
