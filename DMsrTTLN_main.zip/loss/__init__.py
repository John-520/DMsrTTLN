from loss.MMD import *
from loss.adv import *
from loss.KMMD import *